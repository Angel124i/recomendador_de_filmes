let movies = {
  Ação: ["Mad Max: Estrada da Fúria", "John Wick", "Duro de Matar"],
  Comédia: ["Superbad: É Hoje", "Se Beber, Não Case!", "A Ressaca"],
  Drama: ["Os Intocáveis", "Forrest Gump: O Contador de Histórias", "Parasita"],
  Terror: ["Corra!", "Um Lugar Silencioso", "Invocação do Mal"],
  "Ficção Científica": ["A Origem", "Blade Runner 2049", "Matrix"]
};

let selectedGenre = '';
let recommendation = '';

function setup() {
  createCanvas(600, 400); // Aumentando o tamanho da tela
  let genreSelect = createSelect();
  genreSelect.position(20, 80);
  genreSelect.option('Escolha um gênero');
  genreSelect.option('Ação');
  genreSelect.option('Comédia');
  genreSelect.option('Drama');
  genreSelect.option('Terror');
  genreSelect.option('Ficção Científica');
  genreSelect.changed(selectGenre);
  
  let recommendButton = createButton('Recomendar um Filme');
  recommendButton.position(20, 120);
  recommendButton.mousePressed(recommendMovie);
  
  let clearButton = createButton('Limpar Recomendação');
  clearButton.position(20, 160);
  clearButton.mousePressed(clearRecommendation);
  
  // Estilizando os botões
  recommendButton.style('background-color', '#28a745');
  recommendButton.style('color', 'white');
  recommendButton.style('border', 'none');
  recommendButton.style('padding', '10px 15px');
  recommendButton.style('cursor', 'pointer');
  
  clearButton.style('background-color', '#dc3545');
  clearButton.style('color', 'white');
  clearButton.style('border', 'none');
  clearButton.style('padding', '10px 15px');
  clearButton.style('cursor', 'pointer');
}

function draw() {
  background(240);
  fill(50);
  textSize(24);
  textAlign(CENTER);
  text('Recomendador de Filmes', width / 2, 40);
  
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text('Selecione um gênero e receba uma recomendação de filme!', 20, 220);
  
  textSize(20);
  text('Recomendação: ' + recommendation, 20, 260);
}

function selectGenre() {
  selectedGenre = this.value();
}

function recommendMovie() {
  if (selectedGenre !== 'Escolha um gênero' && movies[selectedGenre]) {
    let randomIndex = floor(random(movies[selectedGenre].length));
    recommendation = movies[selectedGenre][randomIndex];
  } else {
    recommendation = 'Por favor, selecione um gênero válido.';
  }
}

function clearRecommendation() {
  recommendation = '';
}